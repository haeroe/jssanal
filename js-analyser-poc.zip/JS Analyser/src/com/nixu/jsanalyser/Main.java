package com.nixu.jsanalyser;

import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.ErrorReporter;
import org.mozilla.javascript.NodeTransformer;
import org.mozilla.javascript.Parser;
import org.mozilla.javascript.ScriptOrFnNode;
import org.mozilla.javascript.tools.ToolErrorReporter;

import tom.library.utils.Viewer;

import com.nixu.jsanalyser.token.types.Token;
import com.nixu.jsanalyser.token.types.TokenList;
import com.nixu.jsanalyser.token.types.token.functionCall;

public class Main {

	public static FunctionDetection parseFunctionDetection(Reader input) throws Exception {
		CompilerEnvirons compilerEnv = new CompilerEnvirons();
		ErrorReporter errorReporter = new ToolErrorReporter(true);
		
		System.out.println("Starting to parse from standard input.");
		
		Parser parser = new Parser(compilerEnv, errorReporter);
		ScriptOrFnNode root = parser.parse(input, "input", 1);
		
		System.out.println("Transforming parse nodes to tokens.");
		
		NodeTransformer nt = new NodeTransformer();
		nt.transform(root);		

		System.out.println("Building token tree.");
		
		TokenBuilder tb = new TokenBuilder();
		Token tokenTree = tb.build(root, root);

		if (System.getProperty("outputTree") != null) {
			System.out.println("Exporting parsed token tree to .dot");
			Viewer.toDot(tokenTree, new FileWriter("token-tree-parsed.dot"));					
		}

		FunctionDetection fd = new FunctionDetection();
		
		System.out.println("Transforming tree.");
		
		tokenTree = fd.transformTree(tokenTree);
		
		System.out.println("Removing unnecessary tokens.");
		
		tokenTree = fd.removeUnnecessaryNodes(tokenTree);
		
		System.out.println("Determining safe nodes.");
		
		tokenTree = fd.determineSafeNodes(tokenTree);

		System.out.println("Initializing function detection");
		
		fd.init(tokenTree);

		if (System.getProperty("outputTree") != null) {
			System.out.println("Exporting processed token tree to .dot");
			Viewer.toDot(tokenTree, new FileWriter("token-tree-processed.dot"));					
		}
		
		return fd;
	}
	
	public static SortedMap<functionCall,List<Collection<? extends Token>>> resolveArgumentValuesFor(FunctionDetection fd, String identifier) {
		
		System.out.println("Resolving arguments for " + identifier);
		
		SortedMap<functionCall,List<Collection<? extends Token>>> callsToResults =
			new TreeMap<functionCall,List<Collection<? extends Token>>>(new Comparator<functionCall>() {
				public int compare(functionCall o1, functionCall o2) {
					return o1.getlineNr() - o2.getlineNr();
				}
			});

		Collection<functionCall> callsToFn = fd.getFunctionCallNodes(identifier);
		for (functionCall call : callsToFn) {
			List<Collection<? extends Token>> argumentResults = new LinkedList<Collection<? extends Token>>();
			TokenList argCursor = call.getarguments();
			while (!argCursor.isEmptytokens()) {
				Token argToken = argCursor.getHeadtokens();
				Collection<? extends Token> possibleValues = fd.resolvePossibleExpressionValues(argToken, new HashSet<Token>());
				argumentResults.add(possibleValues);
				argCursor = argCursor.getTailtokens();
			}
			callsToResults.put(call, argumentResults);
		}
		return callsToResults;
	}
	
	public static void main(String[] args) throws Exception {

		if (args.length != 1) {
			System.out.println("Usage: give target function name as an argument!");
			return;
		}
		
		FunctionDetection fd = parseFunctionDetection(new InputStreamReader(System.in));

		SortedMap<functionCall,List<Collection<? extends Token>>> results = resolveArgumentValuesFor(fd, args[0]);

		System.out.println("\nRESULTS\n");
		
		for (Map.Entry<functionCall,List<Collection<? extends Token>>> e : results.entrySet()) {
			functionCall call = e.getKey();
			System.out.println("Row " + call.getlineNr() + ": " + call);
			int indent = 1;
			for (Collection<? extends Token> result : e.getValue()) {
				for (Token t : result) {
					System.out.println(tabs(indent) + t);
				}
				indent++;
			}
		}
	}

	private static String tabs(int count) {
		StringBuffer buf = new StringBuffer(count);
		for (int i = 0; i < count; i++) {
			buf.append('\t');
		}
		return buf.toString();
	}
	
}
