function myfunction(txt) 
{ 
alert(txt);
}

function test() {
	myfunction("123");
	var x = "456";
	myfunction(x);
	var y = getUserInput(x);
	myfunction(y);
}
