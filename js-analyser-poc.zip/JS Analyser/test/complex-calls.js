function func1() {
	func1();	
	func2("zoo");	
	func3(func2);	
	var x = func6();
	x("sdds");
}

function func2(text, second, third) {
	external.function1(text);
}

function func3(fnRef) {
	fnRef("boo");
}

function func4() {
	func3(function(text) { external.function2(text); });
	func3(func5());	
}

function func5() {
	return function(foo) { external.function3(foo); };	
}

function func6() {
	return func2;
}



















/*

 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

func1()
	CALL func1()
	CALL func2(LITERAL)
	CALL func3(func2)
	x <- RETURN OF CALL func6()
	CALL x()
	


 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

func1	
	func1

func2
	func1	LITERAL
	fucn1-func3	LITERAL

func3
	func1	func2
	func4	ANON_FUNC-1
	func4	func5()

func4

func5
	func3

func6
	func1
	
	
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 
func1
	func1()
	func2(LITERAL)
	func3(func2)
	
func2
	external.function1(ARG_1)
	
func3
	arg1(LITERAL)
 
func4
	func3(ANON_FUNC_1)
	func5
	
func5
	ANON_FUNC_2
	
func6
	
ANON_FUNC_1
	external.function2(ARG_1)

ANON_FUNC_2
	external.function3(ARG_1)
	
*/
