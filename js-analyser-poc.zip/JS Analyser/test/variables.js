var y = 1;
z = x;
y = z;
z = x + y;

function a(x, y) {
	var z = 1;
	w = x + y;
	return x + w;
}
