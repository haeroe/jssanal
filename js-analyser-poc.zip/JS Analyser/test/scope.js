// Function scope
function f() {
	var x = 1;
	return x;

	// For scope
	for (var y = 0; y < 10; y++) {
		var z = y + 1;
	}
}
