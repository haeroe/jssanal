function functionDecl() { }

fnVariable = function() { }

var fnArray = { fn1 : function() { }, fn2 : function() { } }

obj.prop = function() { }

function functionWithParams(param1, param2) { }

function functionWithReturnValue(param) { return 5; }

function functionWithVariables() {
	var var1, var2;
}

function functionWithEnclosedFn() {
	function enclosedFn() { }
}

functionCall(function functionInArgument() { });
