fnCall();

fnCallWithLiteralParams("xyz", "zzz");

fnCallWithVariableParams(a, b, c);

fnCallWithNestedCallInParams(fnAnotherCall());

fnCallWithFunctionParams(function() { });

a.methodCall();

a.methodCallWithParams("xyz");

fnReference = function() { }
fnReference();

chained().method().call();

