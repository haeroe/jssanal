function nested() {
	return "2";
}

function alert(value) {
	return value;
}

simple("1");

simple(nested());

simple(alert("3"));

x = alert("4");

simple(x);

y = alert;
simple(y("5"));

z = simple;
z("6");
